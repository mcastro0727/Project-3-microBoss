import React, { Component } from "react";
import { Col, Row, Container } from "../components/Grid";
import Jumbotron from "../components/Jumbotron";

class SignUp extends Component {
  //   state = {
  //     userEmail: "",
  //     password: ""
  //   };

  render() {
    return (
      <Container>
        <Row>
          <Col size="md-6">
            <Jumbotron>
              <h2>
                {" "}
                <button>Sign Up</button>
              </h2>
            </Jumbotron>
          </Col>
        </Row>
      </Container>
    );
  }
}

export default SignUp;
