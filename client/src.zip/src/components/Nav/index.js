import React from "react";

function Nav() {
  return (
    // <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
    //   <a className="navbar-brand" href="/">
    //     MicroBoss
    //   </a>
    // </nav>
    <nav className="navbar navbar-defualt">
      <div className="container-fluid">
        <div className="navbar-header" href="/">
          Testing
        </div>
      </div>
    </nav>
  );
}

export default Nav;
